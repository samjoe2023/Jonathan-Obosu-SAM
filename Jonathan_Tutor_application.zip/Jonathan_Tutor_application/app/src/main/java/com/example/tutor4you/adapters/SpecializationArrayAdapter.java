//package com.example.tutor4you.adapters;
//
//import android.content.Context;
//import android.widget.ArrayAdapter;
//
//import androidx.annotation.NonNull;
//
//public class SpecializationArrayAdapter extends ArrayAdapter {
//
//    private Context mContext;
//    private String[]  specialization_area;
//
//
//    public SpecializationArrayAdapter(@NonNull Context context, int resource, ) {
//        super(context, resource);
//    }
//}
