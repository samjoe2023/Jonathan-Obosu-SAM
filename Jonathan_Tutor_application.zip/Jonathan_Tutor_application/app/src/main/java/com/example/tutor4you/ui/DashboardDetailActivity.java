package com.example.tutor4you.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tutor4you.R;

public class DashboardDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_detail);
    }
}
